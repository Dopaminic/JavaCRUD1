public class Main {
    public static void main(String[] args){
        new WordManager().start();
        System.out.println("프로그램 종료! 다음에 만나요!!");
    }
}